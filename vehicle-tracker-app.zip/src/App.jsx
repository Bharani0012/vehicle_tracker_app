import React from "react";
import VehicleMap from "./VehicleMap";
export default function App(){
  return <div className="w-screen h-screen overflow-hidden"><VehicleMap /></div>;
}
